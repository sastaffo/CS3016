-- Name: Joe Bloggs,  Username: blgj
module Ex00 where

hello = "I am currently a failing exercise"
