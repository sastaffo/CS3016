module Main where

import Ex00


main = putStrLn hello
